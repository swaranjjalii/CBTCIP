from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet


# Function to create a payment receipt
def create_receipt(file_path):
    # Sample receipt data
    receipt_data = [
        ['Receipt Number:', '123456'],
        ['Date:', '20-09-2023'],
        ['Received From:', 'krishna kulkarni'],
        ['Amount Received:', '$100'],
        ['Payment Method:', 'debit Card'],
    ]

    # Create a PDF document
    doc = SimpleDocTemplate(file_path, pagesize=letter)

    # Create a table with receipt data
    receipt_table = Table(receipt_data, colWidths=[200, 200])

    # Style for the table
    style = TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONT_SIZE', (0, 0), (-1, -1), 12),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
    ])

    receipt_table.setStyle(style)

    # Create a PDF element list
    elements = []
    elements.append(Paragraph('Payment Receipt', getSampleStyleSheet()['Title']))
    elements.append(receipt_table)

    # Build the PDF
    doc.build(elements)


if __name__ == "__main__":
    output_file_path = "payment_receipt.pdf"
    create_receipt(output_file_path)
    print(f"Payment receipt created and saved as '{output_file_path}'.")
