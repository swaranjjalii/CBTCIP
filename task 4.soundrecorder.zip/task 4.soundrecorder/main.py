import sounddevice as sd
import numpy as np
import wave

def record_audio(filename, duration, samplerate=44100):
    print(f"Recording audio for {duration} seconds...")
    audio_data = sd.rec(int(duration * samplerate), samplerate=samplerate, channels=1, dtype=np.int16)
    sd.wait()  # Wait for the recording to complete

    print("Recording completed. Saving audio to file...")
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(samplerate)
        wf.writeframes(audio_data.tobytes())

    print(f"Audio saved to {filename}.")

if __name__ == "__main__":
    filename = "recorded_audio.wav"
    duration = 30 # Recording duration in seconds

    record_audio(filename, duration)
